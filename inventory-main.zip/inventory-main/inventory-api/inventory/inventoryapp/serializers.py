from rest_framework import serializers
from .models import Inventory
class ItemSerializer(serializers.Serializer):
   # id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=100)
    category = serializers.CharField(max_length=100)
    quantity = serializers.IntegerField()
    price = serializers.FloatField()

    def create(self, validated_data):
        #instance=Inventory(**validated_data)
        #instance.save()
        return Inventory.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.name= validated_data.get('name',instance.name)
        instance.category = validated_data.get('category', instance.category)
        instance.quantity = validated_data.get('quantity', instance.quantity)
        instance.price = validated_data.get('price', instance.price)
        instance.save()
        return instance